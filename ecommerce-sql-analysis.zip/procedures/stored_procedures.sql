
DELIMITER $$

CREATE PROCEDURE GetCustomerOrders(IN cid INT)
BEGIN
SELECT *
FROM Orders
WHERE customer_id=cid;
END $$

DELIMITER ;
