# E-Commerce SQL Analysis Project

This project demonstrates:
- Joins
- Window functions
- Analytical queries
- Stored procedures
- Index optimization

## How to run
1 Create database ecommerce;
2 Run schema/create_tables.sql
3 Run data/sample_data.sql
4 Run queries
