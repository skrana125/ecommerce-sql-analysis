
-- Customers with orders
SELECT c.name,o.order_id
FROM Customers c
JOIN Orders o
ON c.customer_id=o.customer_id;

-- Products with categories
SELECT p.product_name,c.category_name
FROM Products p
JOIN Categories c
ON p.category_id=c.category_id;

-- Customers without orders
SELECT c.name
FROM Customers c
LEFT JOIN Orders o
ON c.customer_id=o.customer_id
WHERE o.order_id IS NULL;
