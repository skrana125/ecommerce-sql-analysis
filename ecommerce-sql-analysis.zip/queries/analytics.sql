
-- Monthly revenue
SELECT MONTH(payment_date),
SUM(amount)
FROM Payments
GROUP BY MONTH(payment_date);

-- Repeat customers
SELECT customer_id,
COUNT(order_id)
FROM Orders
GROUP BY customer_id
HAVING COUNT(order_id)>1;

-- Low stock
SELECT product_name
FROM Products
WHERE stock<15;
