
Tables:
Customers
Orders
Products
Payments
Order_Items
Categories

Relationships:
Customers -> Orders
Orders -> Order_Items
Products -> Categories
Orders -> Payments
