
CREATE INDEX idx_customer
ON Orders(customer_id);

CREATE INDEX idx_product
ON Order_Items(product_id);
